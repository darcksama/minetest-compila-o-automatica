#!/usr/bin/env bash

# @FranklinTech
# Franklin Souza

clear

sudo apt install g++ make libc6-dev cmake libpng-dev libjpeg-dev libxi-dev libgl1-mesa-dev libsqlite3-dev libogg-dev libvorbis-dev libopenal-dev libcurl4-gnutls-dev libfreetype6-dev zlib1g-dev libgmp-dev libjsoncpp-dev libzstd-dev libluajit-5.1-dev -y

git clone --depth 1 https://github.com/minetest/minetest.git
cd minetest
git clone --depth 1 https://github.com/minetest/minetest_game.git games/minetest_game
git clone --depth 1 https://github.com/minetest/irrlicht.git lib/irrlichtmt
ln -s ../../irrlicht minetest/lib/irrlichtmt

cd $HOME/minetest
cmake . -DRUN_IN_PLACE=1
make -j$(nproc)

clear && cd $HOME/minetest/bin && ./minetest
