#!/usr/bin/env bash
# ATENÇÃO: Este script deve ser executado como root e com o bash.
# Exemplo de uso: sudo bash script.sh

# Verifica se o script está sendo executado com o bash
if [ -z "$BASH_VERSION" ]; then
  echo "Por favor, execute este script com o bash."
  exit 1
fi

# Verifica se está sendo executado como root
if [ "$EUID" -ne 0 ]; then
  echo "Este script deve ser executado como root."
  exit 1
fi

# Identifica o gerenciador de pacotes
if command -v apt &>/dev/null; then
  PKG_MANAGER="apt"
  INSTALL_CMD="apt install -y"
  UPDATE_CMD="apt update"
elif command -v pacman &>/dev/null; then
  PKG_MANAGER="pacman"
  INSTALL_CMD="pacman -S --needed --noconfirm"
  UPDATE_CMD="pacman -Syu --noconfirm"
elif command -v dnf &>/dev/null; then
  PKG_MANAGER="dnf"
  INSTALL_CMD="dnf install -y"
  UPDATE_CMD="dnf update -y"
else
  echo "Gerenciador de pacotes não suportado. Saindo..."
  exit 1
fi

clear
echo "========================================"
echo " Instalação do Luanti/Minetest"
echo "========================================"
echo "Detectado: $PKG_MANAGER"
echo "Iniciando instalação..."

# Atualiza os pacotes do sistema
$UPDATE_CMD

# Instala dependências conforme a distribuição
case "$PKG_MANAGER" in
  apt)
    $INSTALL_CMD g++ make libc6-dev cmake libpng-dev libjpeg-dev libxi-dev libgl1-mesa-dev \
                 libsqlite3-dev libogg-dev libvorbis-dev libopenal-dev libcurl4-gnutls-dev \
                 libfreetype6-dev zlib1g-dev libgmp-dev libjsoncpp-dev libzstd-dev \
                 libluajit-5.1-dev libsdl2-dev git libjpeg-turbo8
    ;;
  pacman)
    $INSTALL_CMD base-devel gcc cmake libpng libjpeg-turbo libxi mesa sqlite \
                 libogg libvorbis openal curl freetype2 zlib gmp jsoncpp zstd \
                 luajit sdl2 git
    ;;
  dnf)
    $INSTALL_CMD gcc-c++ make glibc-devel cmake libpng-devel libjpeg-devel libXi-devel \
                 mesa-libGL-devel sqlite-devel libogg-devel libvorbis-devel openal-soft-devel \
                 libcurl-devel freetype-devel zlib-devel gmp-devel jsoncpp-devel zstd-devel \
                 luajit-devel SDL2-devel git
    ;;
esac

echo "Clonando o repositório do Luanti..."
git clone --depth 1 https://github.com/luanti-org/luanti.git minetest

if [ ! -d "minetest" ]; then
  echo "Erro ao clonar o repositório do Luanti."
  exit 1
fi

cd minetest || exit 1

echo "Clonando o Minetest Game..."
git clone --depth 1 https://github.com/luanti-org/minetest_game.git games/minetest_game

echo "Clonando o repositório do Irrlicht..."
git clone --depth 1 https://github.com/minetest/irrlicht.git irrlicht

echo "Criando link simbólico para o Irrlicht..."
mkdir -p lib
ln -s ../irrlicht lib/irrlichtmt

echo "Configurando o projeto com CMake..."
cmake . -DRUN_IN_PLACE=1

echo "Compilando o projeto..."
make -j$(nproc)

if [ ! -f "bin/minetest" ]; then
  echo "Falha na compilação. Verifique os logs."
  exit 1
fi

echo "Verificando bibliotecas necessárias..."

# Corrigir possível erro com libjpeg.so.62 no Ubuntu/Debian
if [ "$PKG_MANAGER" = "apt" ] && [ ! -f "/usr/lib/x86_64-linux-gnu/libjpeg.so.62" ]; then
  echo "Corrigindo link da libjpeg..."
  ln -s /usr/lib/x86_64-linux-gnu/libjpeg.so.8 /usr/lib/x86_64-linux-gnu/libjpeg.so.62
  ldconfig
fi

echo "Limpeza e execução do Minetest..."
clear
cd bin || exit 1
./minetest
